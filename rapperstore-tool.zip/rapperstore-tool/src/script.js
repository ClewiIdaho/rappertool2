document.addEventListener("DOMContentLoaded", function () {
    const checklistItems = document.querySelectorAll('.checklist input[type="checkbox"]');
    const progressElement = document.getElementById('progress');
    const notesTextarea = document.getElementById('notes');

    // Load user-specific data from localStorage
    const userProgressKey = 'userProgress';
    const userNotesKey = 'userNotes';
    let userProgress = JSON.parse(localStorage.getItem(userProgressKey)) || Array(checklistItems.length).fill(false);
    let userNotes = localStorage.getItem(userNotesKey) || '';

    // Update checklist based on user-specific data
    checklistItems.forEach(function (item, index) {
        item.checked = userProgress[index];
        item.addEventListener('change', function () {
            userProgress[index] = this.checked;
            updateProgress();
        });
    });

    // Update progress based on checklist
    function updateProgress() {
        const completedItems = userProgress.filter(item => item).length;
        const progressPercentage = (completedItems / checklistItems.length) * 100;
        progressElement.textContent = `Progress: ${progressPercentage.toFixed(2)}%`;

        // Save user-specific progress to localStorage
        localStorage.setItem(userProgressKey, JSON.stringify(userProgress));
    }

    // Load user-specific notes
    notesTextarea.value = userNotes;

    // Save user-specific notes to localStorage on input
    notesTextarea.addEventListener('input', function () {
        userNotes = this.value;
        localStorage.setItem(userNotesKey, userNotes);
    });
});
